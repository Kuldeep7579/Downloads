param($cmd,$out,$dpi)
$dm = New-Object -ComObject WIA.DeviceManager
if ($dm.DeviceInfos.Count -eq 0) { exit 2 }
$info = $dm.DeviceInfos.Item(1)
if ($cmd -eq 'list') { $info.Properties.Item('Name').Value; exit 0 }
$item = $info.Connect().Items.Item(1)
foreach ($p in 6147,6148) { try { $item.Properties.Item([int]$p).Value = [int]$dpi } catch {} }
$img = $item.Transfer('{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}')
if (Test-Path $out) { Remove-Item $out }
$img.SaveFile($out)
