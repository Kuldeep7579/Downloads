# QuickScan
SCAN → FORMAT → FILE NAME → DOWNLOAD

## Run
1. Install Node.js (v16+). 
2. Windows: double-click `start.bat`. Linux/macOS: `./start.sh`
3. Browser opens at http://localhost:3000

## Scanner bridge
- Windows: built-in WIA (no install needed; scanner driver must be installed)
- Linux / macOS: SANE — install `sane-utils` (apt) or `sane-backends` (brew); check with `scanimage -L`
- No scanner? Use "choose a file" fallback inside the app.

Resize can also limit file size in MB (quality is lowered first, then dimensions if needed). Each Scan click adds a page; PDF combines all pages. Scans at 200 DPI.
