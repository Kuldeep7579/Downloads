// QuickScan local scanner bridge — zero dependencies.
// Windows: WIA (PowerShell) | Linux/macOS: SANE (scanimage)
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { execFile } = require('child_process');
const PORT = process.env.PORT || 3000, DPI = 200, win = process.platform === 'win32';
const run = (c, a) => new Promise(r => execFile(c, a, { maxBuffer: 1 << 29, encoding: 'buffer', timeout: 180000 }, (e, so) => r({ e, so })));
const ps = a => run('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'wia.ps1'), ...a]);

async function status() {
  if (win) {
    const r = await ps(['list']); const n = r.so && r.so.toString().trim();
    return n ? { scanner: true, name: n } : { scanner: false };
  }
  const r = await run('scanimage', ['-L']); const m = (r.so ? r.so.toString() : '').match(/device [`']([^`']+)' is (.+)/);
  return m ? { scanner: true, name: m[2] } : { scanner: false };
}
async function scan() {
  if (win) {
    const out = path.join(os.tmpdir(), 'qs_' + Date.now() + '.png');
    await ps(['scan', out, DPI]);
    if (!fs.existsSync(out)) return null;
    const b = fs.readFileSync(out); fs.unlinkSync(out); return b;
  }
  const r = await run('scanimage', ['--format=png', '--resolution', String(DPI)]);
  return r.so && r.so.length > 100 ? r.so : null;
}
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
let busy = false;
http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/api/status') { res.setHeader('Content-Type', 'application/json'); return res.end(JSON.stringify(await status())); }
  if (url === '/api/scan') {
    if (busy) { res.statusCode = 409; return res.end('busy'); }
    busy = true;
    try {
      const b = await scan();
      if (!b) { res.statusCode = 404; return res.end('no scanner'); }
      res.setHeader('Content-Type', b[0] === 0x42 ? 'image/bmp' : b[0] === 0xFF ? 'image/jpeg' : 'image/png'); res.end(b);
    } catch { res.statusCode = 500; res.end('error'); } finally { busy = false; }
    return;
  }
  const f = path.join(__dirname, 'public', url === '/' ? 'index.html' : path.normalize(url).replace(/^(\.\.[\/\\])+/, ''));
  fs.readFile(f, (e, d) => { if (e) { res.statusCode = 404; return res.end(); } res.setHeader('Content-Type', types[path.extname(f)] || 'application/octet-stream'); res.end(d); });
}).listen(PORT, '127.0.0.1', () => console.log('QuickScan running → http://localhost:' + PORT));
